package com.letsTest.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class userDto {

    private Long userId;
    private String name;
    private String email;
    private String username;
    private Boolean status;
    private String collegeName;
    private String collegeRegNo;
    private String mobileNo;
    private String address;
    private String password;
    private String department;
    private String role;
}
